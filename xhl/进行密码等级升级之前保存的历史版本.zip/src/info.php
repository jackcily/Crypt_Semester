<?php

 phpinfo();
