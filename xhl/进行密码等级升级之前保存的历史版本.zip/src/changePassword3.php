<?php
echo $_POST['password'];