<?php
/**
 * Created by PhpStorm.
 * User: xhl
 * Date: 18-7-18
 * Time: 上午9:37
 */

phpinfo();