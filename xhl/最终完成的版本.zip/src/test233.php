<?php
////var_dump([
////    SODIUM_LIBRARY_MAJOR_VERSION,
////    SODIUM_LIBRARY_MINOR_VERSION,
////    SODIUM_LIBRARY_VERSION
////]);
//
//
////
////$p = sodium_crypto_generichash("asd");
//
//
////$password = "123456asd.";
////
////// hash the password and return an ASCII string suitable for storage
////$hash_str = sodium_crypto_pwhash_str(
////    $password,
////    SODIUM_CRYPTO_PWHASH_OPSLIMIT_INTERACTIVE,
////    SODIUM_CRYPTO_PWHASH_MEMLIMIT_INTERACTIVE
////);
//
//
////echo $hash_str;
////echo"        \n";
//
//
////if (sodium_crypto_pwhash_str_verify($hash_str, $password)) {
////    // recommended: wipe the plaintext password from memory
////    sodium_memzero($password);
////    echo "密码验证成功";
////
////    // Password was valid
////} else {
////    // recommended: wipe the plaintext password from memory
////    sodium_memzero($password);
////
////    // Password was invalid.
////}
//
//
//
////var_dump(base64_encode($p));
////
////$q = sodium_crypto_generichash("asd");
////if($p ==$q)echo "验证通过";
//
//
//
//
//
//
//$bob_seed = random_bytes(SODIUM_CRYPTO_BOX_SEEDBYTES);
//$bob_encrypt_kp1 = sodium_crypto_box_seed_keypair($bob_seed);
//
//var_dump(sodium_bin2hex($bob_encrypt_kp1));
//
//$bob_encrypt_kp12 = sodium_crypto_box_seed_keypair($bob_seed);
//
//var_dump(sodium_bin2hex($bob_encrypt_kp12));
//
//$bob_encrypt_kp13 = sodium_crypto_box_seed_keypair($bob_seed);
//
//var_dump(sodium_bin2hex($bob_encrypt_kp13));
//
//$bob_encrypt_kp14 = sodium_crypto_box_seed_keypair($bob_seed);
//
//var_dump(sodium_bin2hex($bob_encrypt_kp14));
//
//
//
//
//
//// On Alice's computer:
//$message = 'Hi, this is me';
//
//
//$message_nonce = random_bytes(SODIUM_CRYPTO_BOX_NONCEBYTES);
//$ciphertext = sodium_crypto_box(
//    $message,
//    $message_nonce,
//    $bob_encrypt_kp1
//);
//
//
//
//$plaintext = sodium_crypto_box_open(
//    $ciphertext,
//    $message_nonce,
//    $bob_encrypt_kp1
//);
//
//
//if ($plaintext === false) {
//    throw new Exception("Malformed message or invalid MAC");
//}else{
//    echo $plaintext;
//}
//
//
//
//
//
//
//
//
//
//$alice_sign_kp = sodium_crypto_sign_keypair();  //alice签名密钥
//
//
////$alice_sign_secretkey = sodium_crypto_sign_secretkey($bob_encrypt_kp1);
////$alice_sign_publickey = sodium_crypto_sign_publickey($bob_encrypt_kp1);
//
//
//
////
////// On Alice's computer:
////$message = 'This comes from Alice.';
////
////
////// On Alice's computer:
////$signature = sodium_crypto_sign_detached(
////    $message,
////    $alice_sign_secretkey
////);
////
////
////// On Bob's computer:
////if (sodium_crypto_sign_verify_detached(
////    $signature,
////    $message,
////    $alice_sign_publickey
////)) {
////    echo "签名验证成功";
////} else {
////    throw new Exception("Invalid signature");
////}
////
////
//
//
//
//
//
//
//
//
//
//
//
//
////$key = "asd";
////
////
////$nonce = random_bytes(SODIUM_CRYPTO_AEAD_CHACHA20POLY1305_NPUBBYTES);
////$ad = 'Additional (public) data';
////$ciphertext = sodium_crypto_aead_chacha20poly1305_encrypt(
////    $message,
////    $ad,
////    $nonce,
////    $key
////);
////
////
////$decrypted = sodium_crypto_aead_chacha20poly1305_decrypt(
////    $ciphertext,
////    $ad,
////    $nonce,
////    $key
////);
////
////var_dump($decrypted);
////
////
////
//
//
//
//
//
//
//
//
//
//
//
//$password = "asd";
//
//
//$out_len = SODIUM_CRYPTO_SIGN_SEEDBYTES;   //
//$salt = random_bytes(SODIUM_CRYPTO_PWHASH_SALTBYTES);
//
////$out_len = SODIUM_CRYPTO_PWHASH_OPSLIMIT_SENSITIVE;
//$nonce = sodium_crypto_pwhash(
//    $out_len,
//    $password,
//    $salt,
//    SODIUM_CRYPTO_PWHASH_OPSLIMIT_INTERACTIVE,
//    SODIUM_CRYPTO_PWHASH_MEMLIMIT_INTERACTIVE
//);
//
//
//$nonce = sodium_hex2bin(substr(sodium_bin2hex($nonce),48));
//
//$nonce2= random_bytes(SODIUM_CRYPTO_AEAD_CHACHA20POLY1305_NPUBBYTES);  //  需要的是8
//
//
//var_dump(sodium_bin2hex($nonce2));
//
//
//
//$key = random_bytes(SODIUM_CRYPTO_AEAD_CHACHA20POLY1305_KEYBYTES);
//
//$ad = 'Additional (public) data';
//$ciphertext = sodium_crypto_aead_chacha20poly1305_encrypt(
//    $message,
//    $ad,
//    $nonce,
//    $key
//);
//
//
//$decrypted = sodium_crypto_aead_chacha20poly1305_decrypt(
//    $ciphertext,
//    $ad,
//    $nonce,
//    $key
//);
//if ($decrypted === false) {
//    throw new Exception("Bad ciphertext");
//}
//else echo "最后一轮进行成功";
//
//




////   首先生成 salt 和 密码的随机数
/// $password = "asd";
//var_dump($salt);
//var_dump(sodium_bin2hex($salt));

//
//
//$salt = random_bytes(SODIUM_CRYPTO_PWHASH_SALTBYTES);
//
//
//
//$out_len = SODIUM_CRYPTO_SIGN_SEEDBYTES;
//$seed = sodium_crypto_pwhash(
//    $out_len,
//    $password,
//    $salt,
//    SODIUM_CRYPTO_PWHASH_OPSLIMIT_INTERACTIVE,
//    SODIUM_CRYPTO_PWHASH_MEMLIMIT_INTERACTIVE
//);
//
//var_dump($seed);
//var_dump(sodium_bin2hex($seed));
//
// /////然后用产生的密码哈西值产生签名公钥对 和 加密公钥对
//
//
//
//
////$bob_seed = random_bytes(SODIUM_CRYPTO_SIGN_SEEDBYTES);
//$bob_sign_kp = sodium_crypto_sign_seed_keypair($seed);
//// Split the key for the crypto_sign API for ease of use
//$alice_sign_secretkey = sodium_crypto_sign_secretkey($bob_sign_kp);
//$alice_sign_publickey = sodium_crypto_sign_publickey($bob_sign_kp);
//
//
////$bob_seed = random_bytes(SODIUM_CRYPTO_BOX_SEEDBYTES);
//$bob_encrypt_kp = sodium_crypto_box_seed_keypair($seed);
//
//
//
//
//// On Alice's computer:
//$message = 'Hi, this is Alice';
//
//$nonce_enc= random_bytes(SODIUM_CRYPTO_BOX_NONCEBYTES);  //存储该对称密钥时 将对应的nonce  一并存储
//$ciphertext = sodium_crypto_box(
//    $message,
//    $nonce,
//    $bob_encrypt_kp
//);
//
//
//$plaintext = sodium_crypto_box_open(
//    $ciphertext,
//    $nonce,
//    $bob_encrypt_kp
//);
//if ($plaintext === false) {
//    throw new Exception("Malformed message or invalid MAC");
//}else {
//    echo "加密解密成功";
//}
//
//
//
///////////////////////////////////////////////
//// On Alice's computer:
//$signature = sodium_crypto_sign_detached(
//    $message,
//    $alice_sign_secretkey
//);
//
//// On Bob's computer:
//if (sodium_crypto_sign_verify_detached(
//    $signature,
//    $message,
//    $alice_sign_publickey
//)
//) {
//    // We've verified the authenticity of message and already had its contents
//    // stored in $message
//
//    echo "签名验证成功";
//} else {
//    throw new Exception("Invalid signature");
//}
//
//
//////////
/////对称加密的时候可以将 pwhash 作为 随机数的一部分
//
//
//$message2 ="asddd";
//
//$key = random_bytes(SODIUM_CRYPTO_AEAD_CHACHA20POLY1305_KEYBYTES);
//
//$nonce = random_bytes(SODIUM_CRYPTO_AEAD_CHACHA20POLY1305_NPUBBYTES);
//$ad = 'Additional (public) data';
//$ciphertext = sodium_crypto_aead_chacha20poly1305_encrypt(
//    $message2,
//    $ad,
//    $nonce,
//    $key
//);
//
//var_dump($ciphertext);
//var_dump ($message2);
//$decrypted = sodium_crypto_aead_chacha20poly1305_decrypt(
//    $ciphertext,
//    $ad,
//    $nonce,
//    $key
//);
//if ($decrypted === false) {
//    throw new Exception("Bad ciphertext");
//}else{
//    echo "对称迦解密成功";
//    echo $decrypted;
//}



//
//
//$_SESSION = array();
//$postArr['password'] ="asd";
//$ret['salt'] = sodium_bin2hex(random_bytes(SODIUM_CRYPTO_PWHASH_SALTBYTES));
//
//$out_len = SODIUM_CRYPTO_SIGN_SEEDBYTES;
//$seed = sodium_crypto_pwhash(
//    $out_len,
//    $postArr['password'],
//    sodium_hex2bin($ret['salt']),
//    SODIUM_CRYPTO_PWHASH_OPSLIMIT_INTERACTIVE,
//    SODIUM_CRYPTO_PWHASH_MEMLIMIT_INTERACTIVE
//);
//// 同一个密码 用同一个salt 会生成同一个种子  可使用该种子生成用户的签名和加密的密码
//
//$user_sign_kp = sodium_crypto_sign_seed_keypair($seed);
//$user_sign_secretkey = sodium_crypto_sign_secretkey($user_sign_kp);
//$user_sign_publickey = sodium_crypto_sign_publickey($user_sign_kp);
//$user_encrypt_kp = sodium_crypto_box_seed_keypair($seed);
//
//
//
//
//$key = random_bytes(SODIUM_CRYPTO_AEAD_CHACHA20POLY1305_KEYBYTES);  //生成对称加密的key
//$nonce = random_bytes(SODIUM_CRYPTO_AEAD_CHACHA20POLY1305_NPUBBYTES);//生成加密对称密钥
//$ad = 'Additional (public) data';
//$sign_secretkey= sodium_bin2hex(sodium_crypto_aead_chacha20poly1305_encrypt(
//    $user_sign_secretkey,
//    $ad,
//    $nonce,
//    $key
//));// 将签名私钥加密后存储
//$crypt_keypair = sodium_bin2hex(sodium_crypto_aead_chacha20poly1305_encrypt(
//    $user_encrypt_kp,
//    $ad,
//    $nonce,
//    $key
//));// 将加密密钥对加密存储
//$_SESSION['passphrase_key'] = sodium_bin2hex($key);
//$_SESSION['passphrase_nonce'] = sodium_bin2hex($nonce);
//$_SESSION['sign_pubkey'] =  sodium_bin2hex(  $user_sign_publickey);
//$_SESSION['encrypt_pair'] = $crypt_keypair;
//$_SESSION['sign_secrkey'] = $sign_secretkey;
//
//
//
//
////////////////////////////////////////////////
//
//$ad = 'Additional (public) data';
//$crypt_keypair = sodium_crypto_aead_chacha20poly1305_decrypt(
//    sodium_hex2bin($_SESSION['encrypt_pair']),
//    $ad,
//    sodium_hex2bin($_SESSION['passphrase_nonce']),
//    sodium_hex2bin($_SESSION['passphrase_key'])
//);  //可用于加密的公钥对
//$sign_seckey = sodium_crypto_aead_chacha20poly1305_decrypt(
//    sodium_hex2bin($_SESSION['sign_secrkey']),
//    $ad,
//    sodium_hex2bin($_SESSION['passphrase_nonce'] ),
//    sodium_hex2bin($_SESSION['passphrase_key'])
//);
//
//var_dump($sign_seckey);
//



$sharekey =  "246172676f6e326924763d3139246d3d33323736382c743d342c703d3124";

$shareKeysh = sodium_crypto_pwhash_str(
    $sharekey ,
    SODIUM_CRYPTO_PWHASH_OPSLIMIT_INTERACTIVE,
    SODIUM_CRYPTO_PWHASH_MEMLIMIT_INTERACTIVE
);


var_dump(sodium_bin2hex($shareKeysh));

if (sodium_crypto_pwhash_str_verify($shareKeysh, $sharekey)) {
    echo "qianming   works";
    // recommended: wipe the plaintext password from memory

} else {

}

